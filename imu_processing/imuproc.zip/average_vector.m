% function to take a vector as input and produce the average value by simply summing it and dividing by
%its length






function [v_av] = average_vector(v)

	v_av = sum(v)/length(v);

end
